class Config:
    MONGO_URI = 'mongodb://root:rootpassword@localhost:27017/'
    MONGO_DB_NAME = 'cms_db'