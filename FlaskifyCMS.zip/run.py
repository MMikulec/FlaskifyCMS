from my_cms.core.app import app
from my_cms.api.routes import api
from my_cms.web.routes import web

# Register blueprints
app.register_blueprint(api)
app.register_blueprint(web)

if __name__ == '__main__':
    app.run()
