from flask import Flask
from flask_pymongo import PyMongo
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
mongo = PyMongo(app)

# Check if database is empty and initialize if necessary
if mongo.db.ContentTypes.count_documents({}) == 0:
    from .db_init import initialize_db
    initialize_db(mongo)
